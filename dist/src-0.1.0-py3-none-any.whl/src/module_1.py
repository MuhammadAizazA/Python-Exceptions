def check_package_working():
    print("Package is working")
    
if __name__=='__main__':
    check_package_working()